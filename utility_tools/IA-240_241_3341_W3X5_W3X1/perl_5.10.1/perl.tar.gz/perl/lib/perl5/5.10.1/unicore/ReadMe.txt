# Date: 2008-03-31, 13:48:00 PDT [KW]
#
# Unicode Character Database
# Copyright (c) 1991-2008 Unicode, Inc.
# For terms of use, see http://www.unicode.org/terms_of_use.html
#
# For documentation, see UCD.html, NamesList.html,
# UAX #38, "Unicode Han Database (Unihan)," and
# UAX #44, "Unicode Character Database."
#

This directory contains final contributory data files
for the Unicode Character Database (UCD) for Unicode 5.1.0.


