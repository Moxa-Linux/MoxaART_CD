/*---------------------------------------------------------------------------*/
/**
  @file		tcpclient.c
  @brief	Simple TCP client

  It connects to a specify ip and port at startup, and then sends string to
  remote TCP server and waits server responses.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "socket.h"

int main()
{
	int clientfd;
	char buf[ 255];
	TCPClientInit( &clientfd);
	TCPClientConnect( clientfd, "192.168.14.26", 502);
	while( 1)
	{
		TCPWrite( clientfd, "hello",  5);
		TCPBlockRead( clientfd, buf, 255);
		printf("Message from server : %s\n", buf);
		sleep( 1);
	}
	return 0;
}

