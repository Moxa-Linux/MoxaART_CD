/*---------------------------------------------------------------------------*/
/**
  @file		tcpserver.c
  @brief	Simple TCP server

  It listen at a specify port and wait connection. It acts as a echo server,
  sends back what it receives.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "socket.h"

int main()
{
	int serverfd, clientfd;
	char buf[ 255], addr[ 255];
	int len;
	TCPServerInit( 502, &serverfd);
	TCPServerWaitConnection( serverfd, &clientfd, addr);
	printf("client connected : %s\n", addr);
	while(len= TCPBlockRead( clientfd, buf, 255))
	{
		buf[ len]= 0;
		printf("Message from client : %s\n", buf);
		TCPWrite( clientfd, buf, len);
	}
	return 0;
}

