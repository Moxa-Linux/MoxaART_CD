#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>

#define SERV_PORT	8002
#define TIMEOUT		3

int main()
{
	int socket1;
	int flag;

	struct sockaddr_in server;
	int len =sizeof(server);
	int trueFlag = 0x1;

	socket1=socket(AF_INET,SOCK_DGRAM,0);
	if( setsockopt(socket1, SOL_SOCKET, SO_BROADCAST, &trueFlag, sizeof(trueFlag)) != 0)
	{
		printf("setsockopt error");
		exit(1);
	}
	{
		flag= fcntl( socket1, F_GETFL);
		flag |= O_NONBLOCK;
		if( fcntl( socket1, F_SETFL, flag) < 0)
		{
			printf("%d - Set socket to nonblock fail", errno);
			exit( -1);
		}
	}
	
	while (1)
	{
		unsigned long t1;
		char buffer[1024]="\0";
		int ret_len= 0;

		server.sin_family=AF_INET;
		server.sin_port=htons( SERV_PORT); 
		server.sin_addr.s_addr=htonl(INADDR_BROADCAST); 
		
		printf("input message\n");
		scanf("%s",buffer);

		sendto(socket1,buffer, 8,0,(struct sockaddr*)&server,len);
		t1= time( NULL);
		while( 1)
		{ 
			if( ( unsigned long)( time( NULL)- t1) >= TIMEOUT)
				break;
			if( recvfrom(socket1,buffer,sizeof buffer,0,(struct sockaddr*)&server,&len) >= 0)
				printf("recv from %s: %s\n", inet_ntoa( server.sin_addr), buffer);
		} 
	}
	close(socket1);

	return 0;
}

