#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/if.h>
#include <errno.h>

#define SERV_PORT 8002
#define PORT_NUM 2

int main()
{
	int i, j, socketfd[ PORT_NUM];
	char devprefix[]= "eth";
	char devname[ 10];

	struct sockaddr_in local;
	struct sockaddr_in from;
	int fromlen =sizeof(from);
	struct ifreq ifr;
	fd_set readfds;
	int tmpfd, maxfd= -1;
	
	FD_ZERO( &readfds);
	for( i= 0; i< PORT_NUM; i++)		// eth0 & eth1 
	{
		socketfd[ i]=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);
		sprintf( devname, "%s%d", devprefix, i);
		strcpy( ifr.ifr_name, devname);
		if( setsockopt( socketfd[ i], SOL_SOCKET, SO_BINDTODEVICE, &ifr, sizeof( ifr)) < 0)
		{
			printf("Port %d setsockopt fail - %d\n", i, errno);
			close( socketfd[ i]);
			socketfd[ i]= -1;
			continue;
		}
		else
			printf("Port %i sersockopt ok.\n", i);

		local.sin_family=AF_INET;
		local.sin_port= htons( SERV_PORT);
		local.sin_addr.s_addr= htonl( INADDR_ANY);
		setsockopt( socketfd[ i], SOL_SOCKET, SO_REUSEADDR, &local, sizeof( local));
		bind(socketfd[ i],(struct sockaddr*)&local, sizeof( local));

		if( socketfd[ i] > maxfd)
			maxfd= socketfd[ i];
	}

	if( maxfd == -1)
	{
		printf("No network device can be use\n");
		exit( -1);
	}

	while( 1)
	{
		char buffer[1024]="\0";
		int devno;

		for( i= 0; i< PORT_NUM; i++)
			if( socketfd[ i] > 0)
				FD_SET( socketfd[ i], &readfds);

		printf("waiting for message from others-------------\n");
		tmpfd= select( maxfd+ 1, &readfds, NULL, NULL, NULL);
		if( tmpfd <= 0)
			continue;
		for( i= 0; i< PORT_NUM; i++)
			if( FD_ISSET( socketfd[ i], &readfds))
				break;
		if( i == PORT_NUM)
			continue;
		devno= i;

		if( i= recvfrom( socketfd[ devno], buffer, sizeof( buffer), 0, ( struct sockaddr*)&from, &fromlen) >= 0)
		{
			printf("eth%d - Received datagram from %s--%s\n",devno, inet_ntoa(from.sin_addr),buffer);
			sendto(socketfd[ devno], buffer, sizeof( buffer), 0, ( struct sockaddr*)&from, fromlen);
			
		}
		else
		{
			printf("recvfrom %d\n", i);
		}
	}	

	close(socketfd[ 0]);
	close(socketfd[ 1]);

	return 0;
}

