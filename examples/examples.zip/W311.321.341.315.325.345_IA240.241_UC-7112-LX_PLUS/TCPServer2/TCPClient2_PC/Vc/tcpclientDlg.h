// tcpclientDlg.h : header file
//

#if !defined(AFX_TCPCLIENTDLG_H__576A41A6_8E69_11D6_A76B_0050BAE51080__INCLUDED_)
#define AFX_TCPCLIENTDLG_H__576A41A6_8E69_11D6_A76B_0050BAE51080__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef struct _PARAVAR{
	char	butflag;
	DWORD	count;
	DWORD	dataidx;
	CString	data;
	DWORD	sendcnt;
	DWORD	recvcnt;
	DWORD	senderr;
	DWORD	recverr;
	DWORD	flag;
	CEdit	*predit;
}PARAVAR, *PPARAVAR;

/////////////////////////////////////////////////////////////////////////////
// CTcpclientDlg dialog

class CTcpclientDlg : public CDialog
{
// Construction
public:
	CWinThread *m_precvthread;
	CWinThread *m_psendthread;
	PARAVAR m_paravar;
	CString m_defultdata;
	CWinThread m_pthread;
	void UpdateButton(void);
	struct sockaddr_in m_sockinfo;
	SOCKET m_sock;
	BOOL m_connectflag;
	DWORD m_ipvar;
	CTcpclientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTcpclientDlg)
	enum { IDD = IDD_TCPCLIENT_DIALOG };
	CIPAddressCtrl	m_serip;
	CString	m_senddata;
	CString	m_count;
	CString	m_port;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTcpclientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTcpclientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnSendbut();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPCLIENTDLG_H__576A41A6_8E69_11D6_A76B_0050BAE51080__INCLUDED_)
