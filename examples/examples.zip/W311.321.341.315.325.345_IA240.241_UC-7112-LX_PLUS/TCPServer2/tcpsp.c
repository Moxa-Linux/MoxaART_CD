/*******************************************************************************
File Name: tcpsp.c
      -- TCP Server + Data Packing Example For PC host AP

Description:
	This program listen on TCP Port 4001, as TCP server.
	And if connection is established, exchange data between serial port and Ethernet and execute data packing.

Data Packing:
	Delimiter Character consist of terminator character and specified length bytes:
	Send a block of data from the serial input buffer to LAN. 
	If the terminator character is encountered 
	or specified length bytes of data are received.  
	
Timeout setting means: 
	Send a block of data from the serial input buffer to LAN. 
	If the time pass by is greater than the timeout setting.
		    
Use SOCKET Library,the header file sdksock.h must be included.
	1	Open serial port.
	2	Configure serial port to 38400bps, N81, no flow control.
	3	Create TCP/IP socket 
	4	Socket Listen on TCP Port 4001.
	5	If TCP connection is established, 
    exchange data between serial port and Ethernet, and execute data packing.

Usage:
    	1. Make downloading file(tcpsp-release or tcpsp-debug) for Moxa embedded computer 
    	    1.1 Create executable file(tcpsp-release or tcps-debug) from source code(tcpsp.c) 
    	    	1.1.1 Modify tcpsp.c: 
    	    		change "TCPPORT" if needed.
    	    	1.1.2 Compiler and link to make tcpsp-release (no debug message) or tcpsp-debug (with debug message) 
	2. Download tcpsp-release or tcpsp-debug to Moxa embedded computer
     	    2.1 Using ftp download tcpsp-release or tcpsp-debug to a Moxa embedded computer unit.    
    	3. Run Application on UC7000 series 
    	4. Execute TCP Client example for PC.[tcpclient.exe or frmClient.exe]
    	   input the TCP Port number equal to "TCPPORT"
    	         UC7000 series Server ip equal to Moxa embedded computer's IP adddress.
    	5. user can check if the sended data received back, and test the Data Packing funtion. 

History:    
	Version		Author		Date          Comment
	1.0		Victor Yu.	01-16-2004    Wrote it.

*******************************************************************************/
#include        <stdio.h>
#include        <stdlib.h>
#include        <sys/types.h>
#include        <sys/socket.h>
#include        <sys/fcntl.h>
#include        <termios.h>
#include        <netinet/in.h>
#include        <errno.h>
#include	<time.h>

#define SPORT		"/dev/ttyM0"
#define TCPPORT		4001

/* Timeout Setting */
#define	TOUT		10	// unit second

/* Delimiter Character */
#define	DEL_CH		'b'
#define	BUF_LEN		1024

char 		sbuf[1024],databuf[1024],rbuf[1024];

int main()
{
	unsigned long		starttime;
	int			sListen, sClient, afd;
	struct sockaddr_in 	local, client;
	int 			ret, size, i, len, data_i=0;
	struct termios		tty;

	printf("start\n");
	/* open serial port */
	if ( (afd=open(SPORT, O_RDWR|O_NDELAY)) < 0 ) {
		printf("open async port [%s] fail [%d]\n", SPORT, errno);
		return 0;
	}

	/* set serial port baud rate */
	tty.c_cflag = CREAD | CLOCAL | B38400 | CS8 | CRTSCTS;
	tty.c_oflag = 0;
	tty.c_lflag = 0;
	tty.c_iflag = 0;
	tty.c_cc[VMIN] = 0;
	tty.c_cc[VTIME] = 0;
	tcsetattr(afd, TCSANOW, &tty);

	/* create socket */
	if ( (sListen=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ){
		printf("open socket fail [%d]\n", errno);
		close(afd);
		return 0;
	}

	local.sin_addr.s_addr = htonl(INADDR_ANY);
	local.sin_family = AF_INET;
	local.sin_port = htons(TCPPORT);
	/* associates a local address with a socket */
	if (bind(sListen, (struct sockaddr *)&local, sizeof(local)) < 0 ){
		printf("socket bind fail [%d]\n", errno);
		close(sListen);
		close(afd);
		return 0;
	}
	/* places a socket a state where it is listening for an incoming connection */
	if (listen(sListen,8) < 0){
		printf("socket listen fail [%d]\n", errno);
		close(sListen);
		close(afd);
		return 0;
	}
 
	size = sizeof(client);
	while( 1 ) {
		printf("accept...");
		if ( (sClient=accept(sListen, (struct sockaddr *)&client, &size)) < 0 ){
			printf("fail [%d]\n", errno);
			break;
		}
		printf("ok\n",3);

		/* set socket to nonblock */
		ret = fcntl(sClient, F_GETFL);
		ret |= O_NONBLOCK;
		if ( fcntl(sClient, F_SETFL, ret) < 0 ) {
			printf("set socket to nonblock fail [%d] !\n", errno);
			break;
		}
						
		starttime = time(NULL);
		while( 1 ){
	  		/* read data from serial port */
			if ( (len=read(afd,sbuf,BUF_LEN)) < 0 ) {
				printf("async port read fail [%d]\n", errno);
	    			close(sClient);
				goto exit_program;
			}else if(len == 0){
				continue;
 			}else{
				for(i=0; i<len; i++) {
					databuf[data_i++] = sbuf[i];
					if ( sbuf[i] == DEL_CH || data_i == BUF_LEN ) {
						/* send data to LAN */
						if((ret = send(sClient,databuf,data_i,0)) != data_i){
							if(ret < 0){
								printf("socket send data fail [%d]\n", errno);
		    						close(sClient);
								goto exit_program;
		    	    	    			}
		    	    	    			data_i = data_i - ret;
	    		    			}else{
				    			data_i = 0;
			    			}
	    	        			starttime = time(NULL);
			    		}
		    		}
	    	    	}

			if ( (time(NULL) - starttime) > TOUT ) {
		    		if ( data_i > 0 ) {
					/* send data to LAN */	
					ret = send(sClient,databuf,data_i,0);
		    			if( ret < 0 ){
						printf("socket send data fail [%d]\n", errno);
		    				close(sClient);
						goto exit_program;
		    			}
					data_i = 0;
					starttime = time(NULL);
		   		}
			}

			/* receive data form LAN */
			ret = recv(sClient, rbuf, BUF_LEN, 0);
			if ( ret == 0 ){
				close(sClient);
	    			break;
			}else if ( ret < 0 ) {
	    			if ( errno == EAGAIN )
					continue;
				if ( errno == ENOTCONN ) {
					close(sClient);
					break;
				}
    				close(sClient);
				goto exit_program;
			}else{
				/* write data to serial port */
		    		if ( (len=write(afd,rbuf,ret)) < 0 ) {
					printf("async port write fail [%d]\n", errno);
    					close(sClient);
					goto exit_program;
		    		} 
			}
 	    	}
	}

exit_program:
	close(sListen);
	close(afd);

	printf("exit\n");
	return 0;
}
