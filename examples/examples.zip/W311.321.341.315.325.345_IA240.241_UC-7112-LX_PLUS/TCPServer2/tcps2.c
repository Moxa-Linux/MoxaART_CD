/*******************************************************************************
File name:	tcps2.c
 
Description:
	This program demo 
	how to use socket lib coding TCP Server program on UC7000 series.
	
	The Hardware connection is following:
	Termianl ---(RS-232)[Moxa embedded computer]--- ~~LAN~~ ---PC Host Example (Windows platform)
	
	This program listen on TCP Port 4001, as TCP server.
	And if connection is established, exchange data between serial port and Ethernet.
	
Usage:
    	1. Make downloading file (tcps2-release or tcps2-debug) for Moxa embedded computer 
    	    1.1 Create executable file(tcps2-release or tcps2-debug) from source code(tcps2.c) 
    	    	1.1.1 Modify tcps2.c: 
    	    		change "TCPPORT" if needed.
    	    	1.1.2 Compiler and link to make tcps2-release(no debug message) or tcps2-debug(with debug message) 
	2. Download tcps2-release or tcps2-debug to Moxa embedded computer 
     	    2.1 Using ftp to download tcps2-release or tcps2-debug to a Moxa embedded computer unit.    
    	3. Run Application on Moxa embedded computer 
    	4. Execute TCP Client example for PC.[tcpclient.exe or frmClient.exe]
    	   input the TCP Port number equal to "TCPPORT"
    	          Server ip equal to Network Enabler PCG's IP adddress.
 
History:    
    	Version		Author		Date		Comment
        1.0		Victor Yu.	01-15-2004      Wrote it.
*******************************************************************************/
#include        <stdio.h>
#include        <stdlib.h>
#include        <sys/types.h>
#include        <sys/socket.h>
#include        <sys/fcntl.h>
#include        <termios.h>
#include        <netinet/in.h>
#include        <errno.h>

#define SPORT		"/dev/ttyM0"	
#define TCPPORT		4001
#define BUFFER_LEN	1024

char 			sbuf[BUFFER_LEN],rbuf[BUFFER_LEN];

int main()
{
	int			sListen, sClient, afd;
	struct sockaddr_in	local, client;
	int 			size,ret,len;
	struct termios		tty;

	printf("start\n");
	/* open serial port */
	if ( (afd=open(SPORT, O_RDWR|O_NDELAY)) < 0 ) {
		printf("open async port [%s] fail [%d] !\n", SPORT, errno);
		return 0;
	}

	/* set serial port baud rate */
	tty.c_cflag = CREAD | CLOCAL | B38400 | CS8 | CRTSCTS;
	tty.c_oflag = 0;
	tty.c_lflag = 0;
	tty.c_iflag = 0;
	tty.c_cc[VMIN] = 0;
	tty.c_cc[VTIME] = 0;
	tcsetattr(afd, TCSANOW, &tty);

	/* create socket */
	if ( (sListen=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0 ){
		printf("open socket fail [%d]\n", errno);
		close(afd);
		return 0;
	}

	local.sin_addr.s_addr = htonl(INADDR_ANY);
	local.sin_family = AF_INET;
	local.sin_port = htons(TCPPORT);

	/* associates a local address with a socket */
	if ( bind(sListen, (struct sockaddr *)&local, sizeof(local)) < 0 ){
		printf("bind fail [%d]\n", errno);
		close(sListen);
		close(afd);
		return 0;
	}

	/* places a socket a state where it is listening for an incoming connection */
	if ( listen(sListen,8) < 0 ){
		printf("listen fail [%d]\n", errno);
		close(sListen);
		close(afd);
		return 0;
	}

	size = sizeof(client);
	while( 1 ) {
        	printf("accept...");
		if ( (sClient=accept(sListen, (struct sockaddr *)&client, &size)) < 0 ){
			printf("failed [%d]\n", errno);
			break;
		}
		printf("ok\n",3);
        
		/* set socket to nonblock */
		ret = fcntl(sClient, F_GETFL);
		ret |= O_NONBLOCK;
		if ( fcntl(sClient, F_SETFL, ret) < 0 ) {
			printf("set socket to nonblock fail [%d] !\n", errno);
			break;
		}

		while( 1 ) {
			/* read data from serial port */
			if ( (len=read(afd,sbuf,BUFFER_LEN)) < 0 ) {
				printf("async port read data fail [%d]\n", errno);
				close(sClient);
				goto exit_program;
			}else if(len == 0){
				continue;
			}else{
				/* send data to LAN */
				ret = send(sClient,sbuf,len,0);
				if( ret < 0 ){
					printf("socket send data fail [%d]\n", errno);
					close(sClient);
					goto exit_program;
				}
			}

			/* receive data form LAN */
			ret = recv(sClient, rbuf, BUFFER_LEN, 0);
			if ( ret == 0 ){
				close(sClient);
				break;
			}else if ( ret < 0 ) {
				if ( errno == EAGAIN )
					continue;
				if ( errno == ENOTCONN ) {
					close(sClient);
					break;
				}
				close(sClient);
				goto exit_program;
			}else{
				/* write data to serial port */
				if ( (len=write(afd,rbuf,ret)) < 0 ) {
					printf("async port write data fail [%d]\n", errno);
					close(sClient);
					goto exit_program;
				} 
			}
		}
	}

exit_program:
	close(sListen);
	close(afd);

	printf("exit\n");
	return 0;
}
