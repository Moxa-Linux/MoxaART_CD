/*---------------------------------------------------------------------------*/
/**
  @file		serial-nonblockread.c
  @brief	Using nonblock mode to read data from serial

  It uses nonblock mode reading data from serial port 2.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "serial.h"

int main()
{
	char buf[ 255];
	int len;

	SerialOpen( PORT2);
	SerialSetSpeed( PORT2, 19200);

	while( 1)
	{
		if( SerialDataInInputQueue( PORT2) <= 1)
			continue;

		SerialNonBlockRead( PORT2, buf, 255);
		printf("%d - %s\n", len, buf);
	}
	return 0;
}
