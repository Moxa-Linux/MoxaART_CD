/*---------------------------------------------------------------------------*/
/**
  @file		serial-blockread.c
  @brief	Using block mode to read data from serial

  It uses block mode reading data from serial port 2.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "serial.h"

int main( int argc, char* argv[])
{
	int port= PORT1;
	int speed= 38400;
	char buf[ 255];
	int i, len;

	if( argc >= 2)
		port= atoi( argv[ 1])- 1;
	if( argc >= 3)
		speed= atoi( argv[ 2]);

	printf("Open port%d, speed= %d\n", port+ 1, speed);
	SerialOpen( port);
	SerialSetSpeed( port, speed);
	
	while( len = SerialBlockRead( port, buf, 255))
	{
		printf("recv: ");
		for( i= 0; i< len; i++)
			printf("[%d]", buf[ i]);
		printf("\n");

		SerialWrite( port, buf, len);
	}

	return 0;
}

