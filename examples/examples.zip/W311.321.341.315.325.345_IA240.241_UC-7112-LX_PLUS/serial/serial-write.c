/*---------------------------------------------------------------------------*/
/**
  @file		serial-write.c
  @brief	Writing data to serial port

  It writes data to serial port 1 and sleep one second.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "serial.h"

int main( int argc, char* argv[])
{
	int port= PORT1;
	int speed= 38400;

	if( argc >= 2)
		port= atoi( argv[ 1])- 1;
	if( argc >= 3)
		speed= atoi( argv[ 2]);

	printf("Open port%d, speed= %d\n", port+ 1, speed);
	SerialOpen( port);
	SerialSetSpeed( port, speed);

	while( 1)
	{
		SerialWrite( port, "hello", 6);
		sleep( 1);
	}
	return 0;
}
