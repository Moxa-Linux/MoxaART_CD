/*---------------------------------------------------------------------------*/
/**
  @file		serial-blockread.c
  @brief	Using block mode to read data from serial

  It uses block mode reading data from serial port 2.

  History:
  Date		Author			Comment
  10-11-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include "serial.h"

int main()
{
	char buf[ 255];
	int len;

	SerialOpen( PORT2);
	while( len = SerialBlockRead( PORT2, buf, 255))
		printf("%d - %s\n", len, buf);
	return 0;
}
