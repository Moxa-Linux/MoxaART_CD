/******************************************************************************
File Name : buzzer.c

Description :
	The program demo how to code buzzer program on UC.

Usage :
	1.Compile this file and execute on UC7000 series.
	2.Choose the number of menu, you can hear a beep sound.

History :
	Versoin		Author		Date		Comment
	1.0		Hank		01-15-2004	Wrote it
*******************************************************************************/
#include "buzzer.h"

int main(int argc, char * argv[])
{
	int 	i;

	BuzzerInit();
	while( 1 ) {
		printf("\nSelect a number of menu, other key to exit.	\n\
	1.one short beep.						\n\
	2.two short beep.						\n\
	3.long beep.							\n\
	4.quit this program.						\n\
Choose : ");
		scanf("%d", &i);
		if ( i == 1 ) {
			BuzzerSound(250);
		} else if ( i == 2 ) {
			BuzzerSound(250);
			BuzzerSound(250);
		} else if ( i == 3 ) {
			BuzzerSound(1500);
		} else if ( i == 4 ) {
			break;
		} else {
			printf("Select error, please select again !\n");
		}
		
	}

	return 0;
}
