#ifndef BUZZER_H
#define BUZZER_H

int BuzzerInit();
void BuzzerSound( int time);

#endif
