#include <stdio.h>
#include <sys/timeb.h>
#include "serial.h"

#define MAXPORT		8
#define BAUDRATE	9600
#define LOG_FILE	"serial.log"

#define GETCLOCKMS(x) {                                 \
		struct timeval tv;                      \
		gettimeofday( &tv, NULL);               \
		x= tv.tv_usec/1000;			\
	}

#define GETCLOCKSECOND(x) {                             \
		x= time(NULL);                          \
	}


int main( void)
{
	char tmp[ 80];
	int i, maxfd= -1;
	int second, ms;

	int tmpfd, fds[ 8];
	fd_set readfds;

	FILE* fd;
	fd= fopen( LOG_FILE, "wt");
	
	for( i= 0; i< MAXPORT; i++)
	{
		SerialOpen( i);
		SerialSetMode( i, RS232_MODE);
		SerialSetSpeed( i, BAUDRATE);

		fds[ i]= FindFD( i);
		if( fds[ i] > maxfd)
			maxfd= fds[ i];
	}
	
	while( 1)
	{
		for( i= 0; i< MAXPORT; i++)
			FD_SET( fds[ i], &readfds);
		tmpfd= select( maxfd+ 1, &readfds, NULL, NULL, NULL);
		for( i= 0; i< MAXPORT; i++)
			if( FD_ISSET( fds[ i], &readfds))
				break;
		if( i == MAXPORT)
			continue;

		SerialBlockRead( i, tmp, 80);

		GETCLOCKMS( ms);
		GETCLOCKSECOND( second);
		fprintf( fd, "PORT%d : %d.%d - %s\n", i+ 1, second, ms, tmp);
		fflush( fd);
	}
	
	return 0;
}

