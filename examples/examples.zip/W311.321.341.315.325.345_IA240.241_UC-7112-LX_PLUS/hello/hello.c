
/*******************************************************************************
File Name:	hello.c

Description:
	This program is just to demo how to development user application. User must first coding program on PC Linux base server with editor. Then compiler it and download it to target.

Usage:
	Just run it on target (Moxa embedded computer).

History:
	Version		Author		Date		Comment
	1.0		Victor Yu.	01-16-2004	Wrote it.
*******************************************************************************/
#include	<stdio.h>
#include	<stdlib.h>

int main(int argc, char *argb[])
{
	printf("Hello\n");
	return 0;
}
