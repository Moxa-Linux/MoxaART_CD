#include <stdio.h>
#include <stdlib.h>
#include <moxadevice.h>

int dostatus[ 8];
	
void setdo( char* str)
{
	int i= 0, j= 0, pin= 0, len= strlen( str);

	for( i= 0; i< 8; i++)
		dostatus[ i]= 0;

	while( i< len)
	{
		while( ( str[ j] != 'O') && ( j< len))
			j++;
		if( j == len)
			break;

		j++;
		pin= str[ j]- '0'- 1;
		dostatus[ pin]= 1;
		i++;
	}

	printf("Set DO..<BR>\n");
	for( i= 0; i< 8; i++)
		set_dout_state( i, dostatus[ i]);
}

int main( int argc, char* argv[])
{
	int state[ 2][ 8];
	int i= 0;
	printf("%s%c%c\n", "Content-Type:text/html;charset=iso-8859-1",13,10);
	printf("<TITLE>DIO results</TITLE>\n");
	printf("<H3>DIO results</H3>\n");

	if( argc == 2)
		setdo( argv[ 1]);
	if( getenv("QUERY_STRING") != NULL)
		setdo( getenv("QUERY_STRING"));

	for( i= 0; i< 8; i++)
	{
		get_din_state( i, &state[ 0][ i]);
		get_dout_state( i, &state[ 1][ i]);
	}

	printf("<table><tr>");
	for( i= 0; i< 8; i++)
		printf("<td>DI%d = %d</td>", i+ 1, state[ 0][ i]);
	printf("</tr><BR><tr>\n");
	for( i= 0; i< 8; i++)
		printf("<td>DO%d = %d</td>", i+ 1, state[ 1][ i]);
	printf("</tr></table><br>\n");

	printf("<FORM action=dioform.cgi method=get>");
	for( i= 0; i< 8; i++)
	{
		if( dostatus[ i] == 0)
			printf("<input type=checkbox name=O%d>DO%d ", i+ 1, i+ 1);
		else
			printf("<input type=checkbox name=O%d checked>DO%d ", i+ 1, i+ 1);
	}
	printf("<br><input type=submit name=Submit<br>\n");
	printf("</FORM>");
	return 0;
}

