
#include	<stdio.h>
#include	<stdlib.h>
#include	<moxadevice.h>
#include	<fcntl.h>

#define MIN_DURATION 40

static char	*DataString[2]={"Low  ", "High "};
static void	hightolowevent(int diport)
{
	printf("\nDIN port %d high to low.\n", diport);
}

static void	lowtohighevent(int diport)
{
	printf("\nDIN port %d low to high.\n", diport);
}

int main(int argc, char * argv[])
{
	int 	i, j, state, retval;
	unsigned long duration;

	while( 1 ) {
		printf("\nSelect a number of menu, other key to exit.	\n\
	1.set high to low event			\n\
	2.get now data.				\n\
	3.set low to high event			\n\
	4.clear event				\n\
	5.set high data.			\n\
	6.set low data.				\n\
	7. quit					\n\
	8. show event and duration				\n\
Choose : ");
	retval =0;
		scanf("%d", &i);
		if ( i == 1 ) {	// set high to low event
			printf("Please keyin the DIN number : ");
			scanf("%d", &i);
			printf("Please input the DIN duration, this minimun value must be over %d : ",MIN_DURATION);
			scanf("%lu", &duration);
			retval=set_din_event(i, hightolowevent, DIN_EVENT_HIGH_TO_LOW, duration);
		} else if ( i == 2 ) {	// get now data
			printf("DIN data  : ");
			for ( j=0; j<MAX_DIN_PORT; j++ ) {
				get_din_state(j, &state);
				printf("%s", DataString[state]);
			}
			printf("\n");
			printf("DOUT data : ");
			for ( j=0; j<MAX_DOUT_PORT; j++ ) {
				get_dout_state(j, &state);
				printf("%s", DataString[state]);
			}
			printf("\n");
		} else if ( i == 3 ) {	// set low to high event
			printf("Please keyin the DIN number : ");
			scanf("%d", &i);
			printf("Please input the DIN duration, this minimun value must be over %d : ",MIN_DURATION);
			scanf("%lu", &duration);
			retval = set_din_event(i, lowtohighevent, DIN_EVENT_LOW_TO_HIGH, duration);
		} else if ( i == 4 ) {	// clear event
			printf("Please keyin the DIN number : ");
			scanf("%d", &i);
			retval=set_din_event(i, NULL, DIN_EVENT_CLEAR, 0);
		} else if ( i == 5 ) {	// set high data
			printf("Please keyin the DOUT number : ");
			scanf("%d", &i);
			retval=set_dout_state(i, 1);
		} else if ( i == 6 ) {	// set low data
			printf("Please keyin the DOUT number : ");
			scanf("%d", &i);
			retval=set_dout_state(i, 0);
		} else if ( i == 7 ) {	// quit
			break;
		} else if ( i == 8 ) {	// show event and duration
			printf("Event:\n");
			for ( j=0; j<MAX_DOUT_PORT; j++ ) {
				retval=get_din_event(j, &i, &duration);
				switch ( i ) {
				case DIN_EVENT_HIGH_TO_LOW :
					printf("(htl,%lu)", duration);
					break;
				case DIN_EVENT_LOW_TO_HIGH :
					printf("(lth,%lu)", duration);
					break;
				case DIN_EVENT_CLEAR :
					printf("(clr,%lu)", duration);
					break;
				default :
					printf("err " );
					break;
				}
			}
			printf("\n");
		} else {
			printf("Select error, please select again !\n");
		}
		
		switch(retval)	{
				case DIO_ERROR_PORT:
					printf("DIO error port\n");
					break;
				case DIO_ERROR_MODE:
					printf("DIO error mode\n");
					break;
				case DIO_ERROR_CONTROL:
					printf("DIO error control\n");
					break;
				case DIO_ERROR_DURATION:
					printf("DIO error duratoin\n");
				case DIO_ERROR_DURATION_20MS:
					printf("DIO error! The duratoin is not a multiple of 20 ms\n");
					break;
		}		
	}

	return 0;
}
