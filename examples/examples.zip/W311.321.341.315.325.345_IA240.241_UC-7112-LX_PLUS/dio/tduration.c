#include	<stdio.h>
#include	<stdlib.h>
#include	<signal.h>
#include <sys/time.h>
#include	<fcntl.h>
#include	<unistd.h>
#include  <pthread.h>
#include	<moxadevice.h>

//#define DEBUG
#ifdef DEBUG
#define dbg_printf(x...)	printf(x)
#else
#define dbg_printf(x...)
#endif

#define DURATION_NUM 7
#define TEST_NUM 100

static int ndin_StateChangeDetected, ndout_StateChangeDetected;
static int nDuration;
static unsigned long duration[2][DURATION_NUM]={  { 50, 40, 35, 30, 25, 20, 15 }, { 160, 140, 120, 100, 80, 60, 40, } };
//static unsigned long duration[2][DURATION_NUM]={  { 50, 40, 35, 30, 25, 20, 15 }, { 170, 150, 130, 120, 110, 100, 80, } };

/****************************************************************************
  When the din state changed form hightolow, this function will be invoked
****************************************************************************/
static void	low2highevent(int diport)
{
	ndin_StateChangeDetected++;
	dbg_printf("din state changed:%d\n",ndin_StateChangeDetected);
}

/****************************************************************************
  This function is used to exchange the dout state periodically
****************************************************************************/
void dout_control(int signo)
{
	int state;
	
	get_dout_state(0, &state);
	dbg_printf("dout state changed:%d\n",state);
	if(state) // exchange the dout state periodically
	{
		ndout_StateChangeDetected++;
		set_dout_state(0, 0);
	}
	else
	{
		set_dout_state(0, 1);
	}
}

void *dio_test_function(void *ptr)
{
	struct itimerval value;
	int j, i, nChoice;
	struct timeval tv;
	
	do {
		
		printf("0.Test for Din duration==0.\n");
		printf("1.Test for Din duration!=0.\n");
		printf("9.Quit.\n" );
		printf("Please select a choice>");
		scanf("%d",&nChoice);
		
		if( nChoice == 9 ){  // Quit
			break;
		}
		else	if( nChoice == 0 ){  //test for din duration==0
			
			for ( nDuration=0; nDuration < DURATION_NUM; nDuration++ )	{
				// configure the dout frequence
				value.it_value.tv_sec = duration[0][nDuration]/1000;
				value.it_value.tv_usec = (duration[0][nDuration]%1000) *1000 ;
				value.it_interval = value.it_value;
				setitimer(ITIMER_PROF,&value,NULL);
				
				ndin_StateChangeDetected = 0;  // reset these counters
				ndout_StateChangeDetected = 0;
				printf("DI duration,:0, DO duration:%d\n",duration[0][nDuration]);
				set_din_event(0, low2highevent, DIN_EVENT_LOW_TO_HIGH, 0);
				
				while( ndin_StateChangeDetected < TEST_NUM );
				printf("ndin_StateChangeDetected:%d, ndout_StateChangeDetected:%d,\n", ndin_StateChangeDetected, ndout_StateChangeDetected);
				printf("loss detection probability:%f\%,\n",(ndout_StateChangeDetected-ndin_StateChangeDetected)*100.0/ndout_StateChangeDetected);
			}
		}//end of if( nChoice ==0 )
		
		else	{ //test for din duration!=0
			
			for ( nDuration=0; nDuration < DURATION_NUM; nDuration++ )	{
				// configure the dout frequence
				value.it_value.tv_sec = duration[1][nDuration]/1000;
				value.it_value.tv_usec = ( duration[1][nDuration]%1000 ) *1000 ;

				value.it_interval = value.it_value;
				//setitimer(ITIMER_VIRTUAL,&value,NULL);
				//setitimer(ITIMER_PROF,&value,NULL);
				setitimer(ITIMER_REAL,&value,NULL);
				
				for( i=0; i<DURATION_NUM; i++) { // dout keep in the same frequence but din set in different duration
					if( duration[1][i] <= duration[1][nDuration] )	{
						ndin_StateChangeDetected = 0;  // reset these counters
						ndout_StateChangeDetected = 0;
						printf("DI duration,:%d, DO duration:%d\n", duration[1][i], duration[1][nDuration] );
						set_din_event(0, low2highevent, DIN_EVENT_LOW_TO_HIGH, duration[1][i]);
						
						while( ndout_StateChangeDetected < TEST_NUM ) {
							pause();
						}
						printf("ndin_StateChangeDetected:%d, ndout_StateChangeDetected:%d,\n", ndin_StateChangeDetected, ndout_StateChangeDetected);
						printf("loss detection probability:%f\%,\n",(ndout_StateChangeDetected-ndin_StateChangeDetected)*100.0/ndout_StateChangeDetected);
					}
				} //end of for( i=0; i<DURATION_NUM; i++)
			}
		}
	} while(1);
	
	pthread_exit(NULL);
}

void init_sigaction(void) 
{
	struct sigaction act;
	act.sa_handler=dout_control;
	act.sa_flags=0;
	sigemptyset(&act.sa_mask);
	sigaction(SIGALRM,&act,NULL);
	//sigaction(SIGPROF,&act,NULL);
	//sigaction(SIGVTALRM, &act, NULL);
}

int main(int argc, char * argv[])
{
	pthread_t	dio_test;
	
	init_sigaction();
	
	set_dout_state(0, 0);  // set the DOUT0 as high
	
	set_din_event(0, low2highevent, DIN_EVENT_LOW_TO_HIGH, duration[1][0]);	
	
	pthread_create(&dio_test,NULL,dio_test_function, NULL);
	
	while( nDuration < DURATION_NUM )
		usleep(100000);

}
