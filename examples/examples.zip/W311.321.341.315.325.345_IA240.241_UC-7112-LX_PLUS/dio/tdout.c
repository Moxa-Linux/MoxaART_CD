#include	<stdio.h>
#include	<stdlib.h>
#include	<signal.h>
#include <sys/time.h>
#include	<fcntl.h>
#include	<unistd.h>
#include  <pthread.h>
#include	<moxadevice.h>

#define DEBUG
#ifdef DEBUG
#define dbg_printf(x...)	printf(x)
#else
#define dbg_printf(x...)
#endif

#define DURATION_NUM 9
#define TEST_NUM 10

static int ndin_StateChangeDetected, ndout_StateChangeDetected;
static unsigned long duration[DURATION_NUM]= {250, 160, 150, 140, 130, 120, 110, 100, 90  };
static bFinished;

/****************************************************************************
  This function is used to exchange the dout state periodically
****************************************************************************/
void dout_control(int signo)
{
	int state;
	
	get_dout_state(0, &state);
	dbg_printf("dout state changed:%d\n",state);
	ndout_StateChangeDetected++;
	if(state) // exchange the dout state periodically
	{
		set_dout_state(0, 0);
	}
	else
	{
		set_dout_state(0, 1);
	}
}

void *dio_test_function(void *ptr)
{
	struct itimerval value;
	int nDuration, nChoice;
	
	while (1) {
		
		for ( nDuration=0; nDuration < DURATION_NUM; nDuration++ )	{
			printf("%d.state changes in %ld msec.\n", nDuration ,duration[nDuration]);
		}
		printf("9.Quit.\n" );
		printf("Please select a choice>");
		scanf("%d",&nChoice);
		
		if( nChoice < 0 || nChoice > DURATION_NUM-1 )
		{
			bFinished = 1;
			pthread_exit(NULL);
		}	
		ndout_StateChangeDetected = 0;
		// control the dout signal
			
		value.it_value.tv_sec = duration[nChoice]/1000;					// configure the dout frequence
		value.it_value.tv_usec = duration[nChoice]%1000;
		value.it_interval = value.it_value;
		setitimer(ITIMER_PROF,&value,NULL);
		//setitimer(ITIMER_VIRTUAL, &value, NULL);
		dbg_printf("time out every:%d sec, %d usec\n", value.it_value.tv_sec, value.it_value.tv_usec);
	
		while( ndout_StateChangeDetected < TEST_NUM );
	
	}
	
	pthread_exit(NULL);
}

void init_sigaction(void) 
{
	struct sigaction act;
	int aaa;
	
	act.sa_handler=dout_control;
	act.sa_flags=0;
	sigemptyset(&act.sa_mask);
	sigaction(SIGPROF,&act,NULL);
	//sigaction(SIGVTALRM, &act, NULL);
} 


int main(int argc, char * argv[])
{
	pthread_t	dio_test;
	
	init_sigaction();
	
	set_dout_state(0, 0);  // set the DOUT0 as high
	
	pthread_create(&dio_test,NULL,dio_test_function, NULL);
	
	while( bFinished == 0 )
		usleep(100000);

}
