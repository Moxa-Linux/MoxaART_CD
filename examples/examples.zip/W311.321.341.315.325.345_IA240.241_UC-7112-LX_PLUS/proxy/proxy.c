/*---------------------------------------------------------------------------*/
/**
  @file		proxy.c
  @brief	Simple proxy program between serial and socket

  It accepts multiple TCP connections and redirect data from socket to serial
  port 1 and it also transmit the data from serial port 1 to each socket
  client.

  History:
  Date		Author			Comment
  10-12-2005	AceLan Kao.		Create it.

  @author AceLan Kao.(acelan_kao@moxa.com.tw)
 */
/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include <pthread.h>

#include "serial.h"
#include "socket.h"

#define SPORT		PORT1
#define TCPPORT		3001
#define BUFFER_LEN	1024

#define MAXCON		10

int fdlist[ MAXCON];

void* ReadDataFromSerial( void* arg)
{
	int port= ( int)arg;
	int i, len, wlen;
	char buf[ BUFFER_LEN];

	SerialOpen( port);
	SerialSetSpeed( port, 9600);

	while( 1)
	{
		len= SerialBlockRead( port, buf, BUFFER_LEN);
		for( i= 0; i< MAXCON; i++)
		{
			if( fdlist[ i] != 0)
			{
				wlen= TCPWrite( fdlist[ i], buf, len);
				// if disconnected then remove fd
				if( wlen < 0)
					fdlist[ i]= 0;
			}
		}
	}

	pthread_exit( NULL);
}

void* ReadDataFromSocket( void* arg)
{
	int fd= ( int)arg;
	char buf[ BUFFER_LEN];
	int len;
	while( 1)
	{
		len= TCPBlockRead( fd, buf, BUFFER_LEN);
		if( len <= 0)
			break;
		SerialWrite( SPORT, buf, len);
	}

	printf("Client %d disconnected\n", fd);
	TCPClientClose( fd);

	pthread_exit( NULL);
}

int main()
{
	int serverfd, clientfd;
	char clientaddr[ BUFFER_LEN];
	int i;

	pthread_t thread1, thread2;

	printf("Start..\n");

	for( i= 0; i< MAXCON; i++)
		fdlist[ i]= 0;

	pthread_create( &thread1, NULL, ReadDataFromSerial, (void*)SPORT);

	TCPServerInit( TCPPORT, &serverfd);

	while( 1)
	{
		if( TCPServerWaitConnection( serverfd, &clientfd, clientaddr) < 0)
		{
			printf("Bind port error\n");
			exit( -1);
		}
		printf("Client %s connected\n", clientaddr);

		for( i= 0; i< MAXCON; i++)
			if( fdlist[ i] == 0)
			{
				fdlist[ i]= clientfd;
				break;
			}

		if( i == MAXCON)
		{
			printf("Connection full, drop connection\n");
			TCPClientClose( clientfd);
		}
		pthread_create( &thread1, NULL, ReadDataFromSocket, (void*)clientfd);
	}

	return 0;
}

